Battle Ship Game
-------------
The page that designed mainly consist of four main side options
HOME: Main webpage with login option. 
PLAY INSTRUCTION: give instruction to user about how to play game. 
GAME: page where field is located . 
YOUR MESSAGE: extra page for communication.

In the folder
1. Open website.html file which is our main website.
2. style2 and style are css files for signup and main front page repectively.
3. For basics i have just add social medias icon which further tasks were to send game invitation.
4. used jquery for mainy sets all sub pages in to main page without refreshing it.


